package com.spring.boot2.Student2.Service;

import java.util.List;

import com.spring.boot2.Student2.Exception.StudentException;
import com.spring.boot2.Student2.Model.Student;

import net.minidev.json.JSONObject;

public interface StudentService {
public void createStudent(Student student) throws StudentException;

public String updateMarks(int id, JSONObject marks) throws StudentException;

public void deletestudent(int id) throws StudentException;

public List<Student> getStudentByAge(int age);

public List<Student> getStudentByGender(String gender);

public List<Student> getStudentByAverageGreaterThan(float average);

public List<Student> getStudentByAverageLessThan(float average);

//public List<Student> serchingStudentData(String quary);

}
