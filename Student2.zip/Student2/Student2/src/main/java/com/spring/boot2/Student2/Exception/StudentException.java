package com.spring.boot2.Student2.Exception;

public class StudentException extends Exception{
	
	public StudentException(String exceptionMessage) {
       super(exceptionMessage);
}
}