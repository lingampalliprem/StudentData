package com.spring.boot2.Student2.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.spring.boot2.Student2.Constants.StudentConstants;
import com.spring.boot2.Student2.Exception.StudentException;
import com.spring.boot2.Student2.Model.Student;
import com.spring.boot2.Student2.Service.StudentService;

import net.minidev.json.JSONObject;

@RestController
public class StudentController {

	@Autowired
	StudentService studentservice;
	
 @PostMapping("/student")
	//@RequestMapping(value = "/student",method = RequestMethod.POST,consumes = {"application/json"})
  public ResponseEntity<?> createStudent(@RequestBody Student student){
	  try {
		  if(student==null) {
			  return ResponseEntity.badRequest().body(StudentConstants.STUDENT_EMPTY);
		  }
		  if(student.firstName.length()<3) {
			  return ResponseEntity.badRequest().body(StudentConstants.FIRST_NAME_INVALID);
		  }
		  if(student.lastName.length()<3) {
			  return ResponseEntity.badRequest().body(StudentConstants.LAST_NAME_INVALID);
	  }
		  if(student.dateOfBirth==null) {
			  return ResponseEntity.badRequest().body(StudentConstants.DATE_OF_BIRTH_EMPTY); 
  }
		  if(!(student.marks1 > 0 && student.marks1 < 100)) {
			  return ResponseEntity.badRequest().body(StudentConstants.MARKS1_RANGE);
}
		  if(!(student.marks2 > 0 && student.marks2 < 100)) {
			  return ResponseEntity.badRequest().body(StudentConstants.MARKS2_RANGE);
	  }
		  if(!(student.marks3 > 0 && student.marks3 < 100)) {
			  return ResponseEntity.badRequest().body(StudentConstants.MARKS3_RANGE);
		  }
		  studentservice.createStudent(student);
		  return ResponseEntity.ok().body(StudentConstants.STUDENT_ADDED);
	  }catch(StudentException exception) {
		  return ResponseEntity.badRequest().body(exception.getMessage());
	  }
	  catch(Exception ex) {
		  return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(StudentConstants.SOMETHING_WENT_WRONG);
	  }
  }

  @PostMapping("/updatemarks")
  public ResponseEntity<?> updateMarks(@RequestParam(value="id") final int id,@RequestBody JSONObject marks){
  try {
	  return ResponseEntity.ok().body(studentservice.updateMarks(id,marks));
  }catch(StudentException exception) {
    return ResponseEntity.badRequest().body(exception.getMessage());
  }
  catch(Exception ex) {
	  return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(StudentConstants.SOMETHING_WENT_WRONG);  
  }
  }
  @DeleteMapping("deletestudents")
  public ResponseEntity<?> deletestudent(@RequestParam(value="id") final int id){
	  try {
		  studentservice.deletestudent(id);
		  return ResponseEntity.ok().body(StudentConstants.STUDENT_DELETED);
  }catch(StudentException exception) {
	    return ResponseEntity.badRequest().body(exception.getMessage());
}
	  catch(Exception ex) {
		  return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(StudentConstants.SOMETHING_WENT_WRONG);  
	  }
  }
  @GetMapping("getstudentbyage/{age}")
  public ResponseEntity<?> getStudentByAge(@PathVariable int age){
	  try {
		  return ResponseEntity.ok().body(studentservice.getStudentByAge(age));
	  } catch(Exception ex) {
		  return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(StudentConstants.SOMETHING_WENT_WRONG);  
	  }
  }
  @GetMapping("getstudentbygender/{gender}")
  public ResponseEntity<?> getStudentByGender(@PathVariable String gender){
  try {
	  System.out.println("gender="+gender);
	    return ResponseEntity.ok().body(studentservice.getStudentByGender(gender));
  } catch(Exception ex) {
	  System.out.println(ex);
	  return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(StudentConstants.SOMETHING_WENT_WRONG);  
  }
}  
  @GetMapping("getstudentbyaveragegreaterthan/{average}")
  public ResponseEntity<?> getStudentByAverageGreaterThan(@PathVariable float average){
	  try {
    return ResponseEntity.ok().body(studentservice.getStudentByAverageGreaterThan(average));
 } catch(Exception ex) {
	  return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(StudentConstants.SOMETHING_WENT_WRONG);  
}
}	  
  
  @GetMapping("getstudentbyaveragelessthan/{average}")
  public ResponseEntity<?> getStudentByAverageLessThan(@PathVariable float average){
  try {
	  
    return ResponseEntity.ok().body(studentservice.getStudentByAverageLessThan(average));
 } catch(Exception ex) {
	  return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(StudentConstants.SOMETHING_WENT_WRONG);  
}
}
// @GetMapping("/search")
// public ResponseEntity<List<Student>> serchingStudentData(@RequestParam String quary){
//	  List<Student> studentlist=studentservice.serchingStudentData(quary);
//	  return new ResponseEntity<>(studentlist,HttpStatus.OK);
//  }
}	  
	  
	  
	  
	  
	  
