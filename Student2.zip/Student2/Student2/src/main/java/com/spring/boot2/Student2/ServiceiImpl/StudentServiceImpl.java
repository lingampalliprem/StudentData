package com.spring.boot2.Student2.ServiceiImpl;

import java.time.LocalDate;
import java.time.Period;
import java.util.List;
import java.util.Optional;

import org.apache.catalina.authenticator.Constants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.boot2.Student2.Constants.StudentConstants;
import com.spring.boot2.Student2.Exception.StudentException;
import com.spring.boot2.Student2.Model.Student;
import com.spring.boot2.Student2.Repository.StudentRepository;
import com.spring.boot2.Student2.Service.StudentService;

import net.minidev.json.JSONObject;
@Service
public class StudentServiceImpl implements StudentService{

	@Autowired
	StudentRepository studentrepository;

	@Override
	public void createStudent(Student student) throws StudentException {
		LocalDate date=LocalDate.parse(student.dateOfBirth);
		int age=calculateAge(date);
		
		if(age > 20 || age < 15) {
		throw new StudentException(StudentConstants.AGE_INVALID);
	}
		if(!student.section.equals(StudentConstants.SECTION_A) && !student.section.equals(StudentConstants.SECTION_B) && !student.section.equals(StudentConstants.SECTION_C) ) {
	 throw new StudentException(StudentConstants.SECTION_INVALID);	
}
	if(!student.gender.equals(StudentConstants.GENDER_M) && !student.gender.equals(StudentConstants.GENDER_F)){
		throw new StudentException(StudentConstants.GENDER_INVALID);
	}
	student.age=age;
	
	int totalMarks=totalMarks(student.marks1,student.marks2,student.marks3);
	
	student.total=totalMarks;
	
	float average=average(totalMarks);
	student.average=average;
	
	student.result=calculateResult(student.marks1,student.marks2,student.marks3) ?"Pass" :"Fail";
	studentrepository.save(student);
}
	private int calculateAge(LocalDate dob) {
		LocalDate currentDate= LocalDate.now();
		if ((dob !=null) && (currentDate !=null)) {
			return Period.between(dob, currentDate).getYears();
		}
		return 0;
	}
	private int totalMarks(int marks1,int marks2,int marks3) {
		return marks1+marks2+marks3;
	}
	private float average(int total) {
		return total/3;
	}
	private Boolean calculateResult(int marks1,int marks2,int marks3) {
		if(marks1<35|| marks2<35 || marks3<35) return false;
	return true;
	}
	@Override
	public String updateMarks(int id, JSONObject marks) throws StudentException {
    if(marks.getAsString("marks1") == null || marks.getAsString("marks1").isEmpty()) {
    	throw new StudentException(StudentConstants.MARKS1_EMPTY);
    }
    if(marks.getAsString("marks2") == null || marks.getAsString("marks2").isEmpty()) {
    	throw new StudentException(StudentConstants.MARKS2_EMPTY);
	}
    if(marks.getAsString("marks3") == null || marks.getAsString("marks3").isEmpty()) {
    	throw new StudentException(StudentConstants.MARKS3_EMPTY);
	}	
    int marks1=Integer.parseInt(marks.getAsString("marks1"));
    int marks2=Integer.parseInt(marks.getAsString("marks2"));
    int marks3=Integer.parseInt(marks.getAsString("marks3"));
    
    if(!(marks1 > 0 && marks1<100)) {
    	throw new StudentException(StudentConstants.MARKS1_RANGE);
    }
    if(!(marks2 > 0 && marks2<100)) {
    	throw new StudentException(StudentConstants.MARKS2_RANGE);
    }
    if(!(marks3 > 0 && marks3<100)) {
    	throw new StudentException(StudentConstants.MARKS3_RANGE);
      }
    
    Optional<Student> student=studentrepository.findById(id);
    if(Optional.of(student).isEmpty()) throw new StudentException(StudentConstants.STUDENT_NOT_FOUND);
    student.get().marks1=marks1;
    student.get().marks2=marks2;
    student.get().marks3=marks3;
    
     int totalMarks=totalMarks(marks1,marks2,marks3);
	
	student.get().total=totalMarks;
	
	float average=average(totalMarks);
	student.get().average=average;
	
	student.get().result=calculateResult(marks1,marks2,marks3) ?"Pass" :"Fail";
	System.out.println(student.get());
	studentrepository.save(student.get());
	return StudentConstants.MARKS_UPDATED;
}
	@Override
	public void deletestudent(int id) throws StudentException {
		// TODO Auto-generated method stub
		Optional<Student> student=studentrepository.findById(id);
		 if(Optional.of(student).isEmpty()) throw new StudentException(StudentConstants.STUDENT_NOT_FOUND);
		 studentrepository.deleteById(id);
	}
	@Override
	public List<Student> getStudentByAge(int age) {

		return studentrepository.findByAge(age);
	}
	@Override
	public List<Student> getStudentByGender(String gender) {
		return studentrepository.findByGender(gender);
	}
	@Override
	public List<Student> getStudentByAverageGreaterThan(float average) {
		
		return studentrepository.findByAverageGreaterThan(average);
	}
	@Override
	public List<Student> getStudentByAverageLessThan(float average) {
		return studentrepository.findByAverageLessThan(average);
	}
//	@Override
//	public List<Student> serchingStudentData(String quary) {
//		return studentrepository.serchingStudentData(quary);
//	}  
	
    
    

}