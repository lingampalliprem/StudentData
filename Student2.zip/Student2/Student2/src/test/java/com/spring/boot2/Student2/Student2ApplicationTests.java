package com.spring.boot2.Student2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Student2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
